/*
 * Copyright 2017 BNY Mellon.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package bnymellon.training.spring.boot.todo.model.response;

import java.util.Collections;

import org.junit.Before;
import org.junit.Test;

import bnymellon.training.spring.boot.todo.model.Todo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class TodoCollectionServiceResponseTest {
    private TodoCollectionServiceResponse todoCollectionServiceResponse1;
    private TodoCollectionServiceResponse todoCollectionServiceResponse2;
    private TodoCollectionServiceResponse todoCollectionServiceResponse3;
    private TodoCollectionServiceResponse todoCollectionServiceResponse4;

    @Before
    public void setUp() throws Exception {
        Todo todo1 = new Todo();
        todo1.setId(3L);
        todo1.setName("MyTodo 8");
        todo1.setActiveFlag(true);
        todo1.setAssignee("XBBLNNN");
        todo1.setDue("Today");
        todo1.setNotes("Some notes");

        Metadata metadata1 = new Metadata();
        metadata1.setDescription("Description");
        metadata1.setRequestId("requestId");
        metadata1.setRequestTimestamp("requestTimestamp");
        metadata1.setResponseId("responseId");
        metadata1.setResponseTimestamp("responseTimestamp");
        metadata1.setServiceName("serviceName");
        metadata1.setServiceVersion("serviceVersion");
        metadata1.setStatus(null);

        todoCollectionServiceResponse1 = new TodoCollectionServiceResponse();
        todoCollectionServiceResponse1.setTodos(Collections.singletonList(todo1));

        todoCollectionServiceResponse2 = new TodoCollectionServiceResponse();
        todoCollectionServiceResponse2.setTodos(Collections.singletonList(todo1));

        todoCollectionServiceResponse3 = new TodoCollectionServiceResponse();
        todoCollectionServiceResponse3.setMetadata(metadata1);

        todoCollectionServiceResponse4 = new TodoCollectionServiceResponse();
    }

    @Test
    public void testEquals() throws Exception {
        assertEquals("TodoCollectionServiceResponse1 and TodoCollectionServiceResponse2 should be equal", todoCollectionServiceResponse1, todoCollectionServiceResponse2);
        assertNotEquals("TodoCollectionServiceResponse1 and TodoCollectionServiceResponse3 should not be equal", todoCollectionServiceResponse1, todoCollectionServiceResponse3);
        assertNotEquals("TodoCollectionServiceResponse1 and TodoCollectionServiceResponse3 should not be equal", todoCollectionServiceResponse1, todoCollectionServiceResponse4);
    }

    @Test
    public void testHashCode() throws Exception {
        assertEquals("TodoCollectionServiceResponse1 and TodoCollectionServiceResponse2 should have the same hashCode", todoCollectionServiceResponse1.hashCode(), todoCollectionServiceResponse2.hashCode());
        assertNotEquals("TodoCollectionServiceResponse1 and TodoCollectionServiceResponse3 should not have the same hashCode", todoCollectionServiceResponse1.hashCode(), todoCollectionServiceResponse3.hashCode());
        assertNotEquals("TodoCollectionServiceResponse1 and TodoCollectionServiceResponse3 should not have the same hashCode", todoCollectionServiceResponse1.hashCode(), todoCollectionServiceResponse4.hashCode());
    }

    @Test
    public void testToString() throws Exception {
        assertEquals("TodoCollectionServiceResponse1 and TodoCollectionServiceResponse2 should have the same toString", todoCollectionServiceResponse1.toString(), todoCollectionServiceResponse2.toString());
        assertNotEquals("TodoCollectionServiceResponse1 and TodoCollectionServiceResponse3 should not have the same toString", todoCollectionServiceResponse1.toString(), todoCollectionServiceResponse3.toString());
        assertNotEquals("TodoCollectionServiceResponse1 and TodoCollectionServiceResponse3 should not have the same toString", todoCollectionServiceResponse1.toString(), todoCollectionServiceResponse4.toString());
    }

}