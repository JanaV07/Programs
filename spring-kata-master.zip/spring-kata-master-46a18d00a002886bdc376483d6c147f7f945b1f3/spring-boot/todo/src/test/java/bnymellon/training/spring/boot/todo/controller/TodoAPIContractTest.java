/*
 * Copyright 2017 BNY Mellon.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package bnymellon.training.spring.boot.todo.controller;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;

import bnymellon.training.spring.boot.todo.AbstractTodoMockSetupTest;
import bnymellon.training.spring.boot.todo.TodoConstants;
import bnymellon.training.spring.boot.todo.model.Todo;
import bnymellon.training.spring.boot.todo.model.exception.InvalidAssigneeException;
import bnymellon.training.spring.boot.todo.model.exception.InvalidIdException;
import bnymellon.training.spring.boot.todo.model.exception.TodoNotFoundException;
import bnymellon.training.spring.boot.todo.model.response.TodoErrorResponse;
import bnymellon.training.spring.boot.todo.model.response.TodoResponse;
import bnymellon.training.spring.boot.todo.model.response.TodoServiceResponse;
import bnymellon.training.spring.boot.todo.service.TodoService;
import bnymellon.training.spring.boot.todo.service.TodoServiceImpl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TodoAPIContractTest extends AbstractTodoMockSetupTest {

    private TodoService todoService;
    private TodoAPIContract todoAPIContract;

    @Before
    public void setUp() {
        super.setUp();
        todoService = new TodoServiceImpl(todoRepository);
        todoAPIContract = new TodoAPIContractImpl(todoService);
    }

    @Test
    public void addTodo() throws Exception {
        Todo todo1 = new Todo();
        todo1.setId(3L);
        todo1.setName("MyTodo 8");
        todo1.setActiveFlag(true);
        todo1.setAssignee("XBBLNNN");
        todo1.setDue("Today");
        todo1.setNotes("Some notes");
        TodoServiceResponse savedTodo = todoAPIContract.addTodo(todo1, null);
        assertEquals(todo1, savedTodo.getTodo());
    }

    @Test
    public void getTodo() {
        assertEquals(
                "Todo2 should be fetched",
                todo2,
                todoAPIContract.getTodo("2", null).getTodo());
    }

    @Test(expected = InvalidIdException.class)
    public void getNonExistingTodo() {
        String todoId = null;

        TodoResponse todoById = todoAPIContract.getTodo(todoId, null);

        String expectedMessage = String.format(TodoConstants.INVALID_ID_MESSAGE, todoId);

        assertTrue(todoById instanceof TodoErrorResponse);

        TodoErrorResponse errorResponse = (TodoErrorResponse) todoById;

        assertEquals(
                "Should throw an InvalidIdException",
                expectedMessage,
                errorResponse.getIssues().get(0).getIssueMessage()
        );

        assertEquals(
                "Should match a PreCondition failure",
                HttpStatus.PRECONDITION_FAILED.toString(),
                errorResponse.getIssues().get(0).getIssueCode()
        );
    }

    @Test
    public void getAllTodos() {
        assertEquals(
                "There should be a total of 2 Todos",
                2,
                todoAPIContract.getTodos(false, null).getTodos().size());
    }

    @Test
    public void getAllActiveTodos() {
        assertEquals(
                "There should be a total of 2 active Todos",
                2,
                todoAPIContract.getTodos(true, null).getTodos().size());
    }

    @Test
    public void getTodosByAssignee() {
        List<Todo> fetchedTodos = todoAPIContract.getTodosByAssignee("XBBLNNN", null).getTodos();
        assertEquals(1, fetchedTodos.size());
        Todo firstTodo = fetchedTodos.get(0);
        assertEquals(
                "The todo fetched should have a name of: MyTodo 1",
                "MyTodo 1",
                firstTodo.getName());
    }

    @Test(expected = InvalidAssigneeException.class)
    public void getNonExistingAssignee() {
        String assignee = null;

        TodoResponse todosByAssignee = todoAPIContract.getTodosByAssignee(assignee, null);

        assertTrue(todosByAssignee instanceof TodoErrorResponse);

        TodoErrorResponse errorResponse = (TodoErrorResponse) todosByAssignee;

        String expectedMessage = String.format(TodoConstants.INVALID_NULL_ASSIGNEE_MESSAGE, assignee);

        assertEquals(
                "Should throw an InvalidAssigneeException",
                expectedMessage,
                errorResponse.getIssues().get(0).getIssueMessage()
        );

        assertEquals(
                "Should match a PreCondition failure",
                HttpStatus.PRECONDITION_FAILED.toString(),
                errorResponse.getIssues().get(0).getIssueCode()
        );
    }

    @Test(expected = InvalidAssigneeException.class)
    public void getSmallValueForAssignee() {
        String assignee = "ABC";

        TodoResponse todosByAssignee = todoAPIContract.getTodosByAssignee(assignee, null);

        assertTrue(todosByAssignee instanceof TodoErrorResponse);

        TodoErrorResponse errorResponse = (TodoErrorResponse) todosByAssignee;

        String expectedMessage = String.format(TodoConstants.INVALID_ASSIGNEE_LENGTH_MESSAGE, assignee);

        assertEquals(
                "Should throw an InvalidAssigneeException",
                expectedMessage,
                errorResponse.getIssues().get(0).getIssueMessage()
        );

        assertEquals(
                "Should match a PreCondition failure",
                HttpStatus.PRECONDITION_FAILED.toString(),
                errorResponse.getIssues().get(0).getIssueCode()
        );
    }

    @Test(expected = InvalidAssigneeException.class)
    public void getLargeValueForAssignee() {
        String assignee = "ABCDEFGHIJKL";

        TodoResponse todosByAssignee = todoAPIContract.getTodosByAssignee(assignee, null);

        assertTrue(todosByAssignee instanceof TodoErrorResponse);

        TodoErrorResponse errorResponse = (TodoErrorResponse) todosByAssignee;

        String expectedMessage = String.format(TodoConstants.INVALID_ASSIGNEE_LENGTH_MESSAGE, assignee);

        assertEquals(
                "Should throw an InvalidAssigneeException",
                expectedMessage,
                errorResponse.getIssues().get(0).getIssueMessage()
        );

        assertEquals(
                "Should match a PreCondition failure",
                HttpStatus.PRECONDITION_FAILED.toString(),
                errorResponse.getIssues().get(0).getIssueCode()
        );
    }

    @Test
    public void updateTodo() {
        todo1.setName("MyTodo 8");
        todo1.setActiveFlag(true);
        todo1.setAssignee("XBBLNNN");
        todo1.setDue("Tomorrow");
        todo1.setNotes("Some notes");
        Todo savedTodo = todoAPIContract.updateTodo("1", todo1, null).getTodo();
        assertEquals(
                "The update should alter the Due date from ",
                "Tomorrow",
                savedTodo.getDue());
    }

    @Test(expected = TodoNotFoundException.class)
    public void updateNonExistentTodo() {
        Todo todo7 = new Todo();
        todo7.setName("MyTodo 8");
        todo7.setActiveFlag(true);
        todo7.setAssignee("XBBLNNN");
        todo7.setDue("Tomorrow");
        todo7.setNotes("Some notes");

        TodoResponse todoUpdateAttemptResponse = todoAPIContract.updateTodo("7", todo7, null);

        assertTrue(todoUpdateAttemptResponse instanceof TodoErrorResponse);

        TodoErrorResponse errorResponse = (TodoErrorResponse) todoUpdateAttemptResponse;

        String expectedMessage = String.format(TodoConstants.TODO_NOT_FOUND_EXCEPTION, todo7.getId());

        assertEquals(
                "Should throw an TodoNotFound",
                expectedMessage,
                errorResponse.getIssues().get(0).getIssueMessage()
        );

        assertEquals(
                "Should match a NotFound failure",
                HttpStatus.NOT_FOUND.toString(),
                errorResponse.getIssues().get(0).getIssueCode()
        );
    }

    @Test
    public void deleteTodo() {
        Todo deletedTodo = todoAPIContract.deleteTodo("1", null).getTodo();
        assertFalse(
                "The deletion should set the activeFlag to false",
                deletedTodo.getActiveFlag());
    }

    @Test(expected = TodoNotFoundException.class)
    public void deleteNonExistentTodo() {

        TodoResponse todoDeleteAttemptResponse = todoAPIContract.deleteTodo("7",null);

        assertTrue(todoDeleteAttemptResponse instanceof TodoErrorResponse);

        TodoErrorResponse errorResponse = (TodoErrorResponse) todoDeleteAttemptResponse;

        String expectedMessage = String.format(TodoConstants.TODO_NOT_FOUND_EXCEPTION, 7);

        assertEquals(
                "Should throw an TodoNotFound",
                expectedMessage,
                errorResponse.getIssues().get(0).getIssueMessage()
        );

        assertEquals(
                "Should match a NotFound failure",
                HttpStatus.NOT_FOUND.toString(),
                errorResponse.getIssues().get(0).getIssueCode()
        );
    }

}