/*
 * Copyright 2017 BNY Mellon.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package bnymellon.training.spring.boot.todo.dao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseOperation;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.DatabaseTearDown;

import bnymellon.training.spring.boot.todo.TodoApplication;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TodoApplication.class)
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class, DirtiesContextTestExecutionListener.class,
        TransactionalTestExecutionListener.class, DbUnitTestExecutionListener.class})
@DatabaseSetup(TodoRepositoryTest.DATASET)
@DatabaseTearDown(type = DatabaseOperation.DELETE_ALL, value = {TodoRepositoryTest.DATASET})
@DirtiesContext
public class TodoRepositoryTest {
    protected static final String DATASET = "classpath:datasets/todos.xml";

    @Autowired
    private TodoRepository repository;

    @Test
    public void findOne() {
        assertNotNull(
                "There should be a Todo with id: 3.",
                repository.findOne(3L));
        assertNull(
                "There should be no Todo with id: 9.",
                repository.findOne(9L));
    }

    @Test
    public void findByAssignee() {
        assertEquals(
                "There should be three Todos for the assignee: XBBL9K3.",
                3,
                repository.findByAssignee("XBBL9K3").size());
    }

    @Test
    public void findAll() {
        assertEquals(
                "There should be seven total Todos.",
                7,
                repository.findAll().size());
    }

    @Test
    public void findActive() {
        assertEquals(
                "There should be four active Todos",
                4,
                repository.findByActiveFlagTrue().size());
    }

    @Test
    public void findActiveByAssignee() {
        assertEquals(
                "There should be one active Todo for the assignee: XBBL9K3",
                1,
                repository.findByActiveFlagTrueAndAssignee("XBBL9K3").size());
    }

    @Test
    public void findCustomNotes() {
        assertEquals(
                "There should be one Todo with a note containing the word: Fix",
                1,
                repository.findCustomNotes("Fix").get().size());
    }

    @Test
    public void compareCustomAndStandardNotes() {
        assertEquals(
                "The number of Todos with a note containing the word: Fix should be the same with both custom and named query styles.",
                repository.findCustomNotes("Fix").get().size(),
                repository.findByNotesContaining("Fix").get().size());
    }

}
