/*
 * Copyright 2017 BNY Mellon.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package bnymellon.training.spring.boot.todo;

import java.util.Arrays;

import org.mockito.Mock;

import bnymellon.training.spring.boot.todo.dao.TodoRepository;
import bnymellon.training.spring.boot.todo.model.Todo;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AbstractTodoMockSetupTest {
    protected Todo todo1;
    protected Todo todo2;

    @Mock
    protected TodoRepository todoRepository;

    public void setUp() {

        todo1 = new Todo();
        //This is not needed, but added so we can test equals() later.
        todo1.setId(1L);
        todo1.setName("MyTodo 1");
        todo1.setActiveFlag(true);
        todo1.setAssignee("XBBLNNN");
        todo1.setDue("Today");
        todo1.setNotes("Some notes");

        todo2 = new Todo();
        //This is not needed, but added so we can test equals() later.
        todo2.setId(2L);
        todo2.setName("MyTodo 2");
        todo2.setActiveFlag(true);
        todo2.setAssignee("XBBLYYY");
        todo2.setDue("Soon");
        todo2.setNotes("Some notes for Todo 2");

        // Mocking the dao layer.
        todoRepository = mock(TodoRepository.class);

        // Return the same todo as the one saved.
        when(todoRepository.save(any(Todo.class))).thenAnswer(invocation -> invocation.getArguments()[0]);

        // Return a new todo of ID 1 when fetched.
        when(todoRepository.findOne(1L)).thenReturn(todo1);
        // Return a new todo of ID 2 when fetched.
        when(todoRepository.findOne(2L)).thenReturn(todo2);

        // Return a list of todos when all fetched.
        when(todoRepository.findAll()).thenReturn(Arrays.asList(new Todo[]{todo1, todo2}));

        // Return a list of todos when all active fetched.
        when(todoRepository.findByActiveFlagTrue()).thenReturn(Arrays.asList(new Todo[]{todo1, todo2}));

        when(todoRepository.saveAndFlush(any(Todo.class))).thenAnswer(invocation -> invocation.getArguments()[0]);

        // Return a new todo of ID 1 when fetched for assignee XBBLNNN.
        when(todoRepository.findByAssignee(eq("XBBLNNN"))).thenReturn(Arrays.asList(new Todo[]{todo1}));
        // Return a new todo of ID 2 when fetched for assignee XBBLYYY.
        when(todoRepository.findByAssignee(eq("XBBLYYY"))).thenReturn(Arrays.asList(new Todo[]{todo2}));

    }
}
