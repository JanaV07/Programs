/*
 * Copyright 2017 BNY Mellon.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package bnymellon.training.spring.boot.todo.service;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import bnymellon.training.spring.boot.todo.AbstractTodoMockSetupTest;
import bnymellon.training.spring.boot.todo.model.Todo;
import bnymellon.training.spring.boot.todo.model.exception.InvalidAssigneeException;
import bnymellon.training.spring.boot.todo.model.exception.InvalidIdException;
import bnymellon.training.spring.boot.todo.model.exception.TodoNotFoundException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TodoServiceTest extends AbstractTodoMockSetupTest {

    private TodoServiceImpl todoService;

    @Before
    public void setUp() {
        super.setUp();
        todoService = new TodoServiceImpl(todoRepository);
    }

    @Test
    public void saveTodo() {
        Todo todo1 = new Todo();
        todo1.setId(3L);
        todo1.setName("MyTodo 8");
        todo1.setActiveFlag(true);
        todo1.setAssignee("XBBLNNN");
        todo1.setDue("Today");
        todo1.setNotes("Some notes");
        Todo savedTodo = todoService.saveTodo(todo1);
        assertEquals(todo1, savedTodo);
    }

    @Test
    public void getTodo() {
        assertEquals(
                "Todo2 should be fetched",
                todo2,
                todoService.getTodo("2"));
    }

    @Test(expected = InvalidIdException.class)
    public void getNonExistingTodo() {
        assertEquals(
                "Should throw an InvalidIdException",
                null,
                todoService.getTodo(null));
    }

    @Test
    public void getAllTodos() {
        assertEquals(
                "There should be a total of 2 Todos",
                2,
                todoService.getAllTodos(false).size());
    }

    @Test
    public void getAllActiveTodos() {
        assertEquals(
                "There should be a total of 2 active Todos",
                2,
                todoService.getAllTodos(true).size());
    }

    @Test
    public void getTodosByAssignee() {
        List<Todo> fetchedTodos = todoService.getTodosByAssignee("XBBLNNN");
        assertEquals(1, fetchedTodos.size());
        Todo firstTodo = fetchedTodos.get(0);
        assertEquals(
                "The todo fetched should have a name of: MyTodo 1",
                "MyTodo 1",
                firstTodo.getName());
    }

    @Test(expected = InvalidAssigneeException.class)
    public void getNonExistingAssignee() {
        assertEquals(
                "Should throw an InvalidAssigneeException",
                null,
                todoService.getTodosByAssignee(null));
    }

    @Test(expected = InvalidAssigneeException.class)
    public void getSmallValueForAssignee() {
        assertEquals(
                "Should throw an InvalidAssigneeException",
                null,
                todoService.getTodosByAssignee("ABC"));
    }

    @Test(expected = InvalidAssigneeException.class)
    public void getLargeValueForAssignee() {
        assertEquals(
                "Should throw an InvalidAssigneeException",
                null,
                todoService.getTodosByAssignee("ABCDEFGHIJKL"));
    }

    @Test
    public void updateTodo() {
        todo1.setName("MyTodo 8");
        todo1.setActiveFlag(true);
        todo1.setAssignee("XBBLNNN");
        todo1.setDue("Tomorrow");
        todo1.setNotes("Some notes");
        Todo savedTodo = todoService.updateTodo("1", todo1);
        assertEquals(
                "The update should alter the Due date from ",
                "Tomorrow",
                savedTodo.getDue());
    }

    @Test(expected = TodoNotFoundException.class)
    public void updateNonExistentTodo() {
        Todo todo7 = new Todo();
        todo7.setName("MyTodo 8");
        todo7.setActiveFlag(true);
        todo7.setAssignee("XBBLNNN");
        todo7.setDue("Tomorrow");
        todo7.setNotes("Some notes");
        Todo savedTodo = todoService.updateTodo("7", todo7);
    }

    @Test
    public void deleteTodo() {
        Todo savedTodo = todoService.deleteTodo("1");
        assertFalse(
                "The deletion should set the activeFlag to false",
                savedTodo.getActiveFlag());
    }

    @Test(expected = TodoNotFoundException.class)
    public void deleteNonExistentTodo() {
        Todo savedTodo = todoService.deleteTodo("7");
    }

}