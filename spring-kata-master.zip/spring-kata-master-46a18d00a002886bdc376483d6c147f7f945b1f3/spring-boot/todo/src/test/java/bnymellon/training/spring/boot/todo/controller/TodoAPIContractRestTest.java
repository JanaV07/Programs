/*
 * Copyright 2017 BNY Mellon.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package bnymellon.training.spring.boot.todo.controller;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;

import bnymellon.training.spring.boot.todo.TodoApplication;
import bnymellon.training.spring.boot.todo.TodoConstants;
import bnymellon.training.spring.boot.todo.dao.TodoRepository;
import bnymellon.training.spring.boot.todo.model.Todo;
import bnymellon.training.spring.boot.todo.model.exception.InvalidAssigneeException;
import bnymellon.training.spring.boot.todo.model.exception.TodoNotFoundException;
import bnymellon.training.spring.boot.todo.service.TodoServiceImpl;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = TodoApplication.class)
@ComponentScan({"bnymellon.training.spring.boot.todo"})
@EnableAutoConfiguration
public class TodoAPIContractRestTest {

    @LocalServerPort
    private int port;

    @Mock
    private TodoRepository todoRepository;

    @Autowired
    private TodoServiceImpl todoService;

    private Todo todo1;
    private Todo todo2;

    @Before
    public void setUp() {
        todo1 = new Todo();
        //This is not needed, but added so we can test equals() later.
        todo1.setId(1L);
        todo1.setName("MyTodo 1");
        todo1.setActiveFlag(true);
        todo1.setAssignee("XBBLNNN");
        todo1.setDue("Today");
        todo1.setNotes("Some notes");

        todo2 = new Todo();
        //This is not needed, but added so we can test equals() later.
        todo2.setId(2L);
        todo2.setName("MyTodo 2");
        todo2.setActiveFlag(true);
        todo2.setAssignee("XBBLYYY");
        todo2.setDue("Soon");
        todo2.setNotes("Some notes for Todo 2");

        // Mocking the dao layer.
        todoRepository = mock(TodoRepository.class);
        todoService.setTodoRepository(todoRepository);

        // Return the same todo as the one saved.
        when(todoRepository.save(any(Todo.class)))
                .thenAnswer(invocation -> invocation.getArguments()[0]);

        // Return a new todo of ID 1 when fetched.
        when(todoRepository.findOne(1L))
                .thenReturn(todo1);
        // Return a new todo of ID 2 when fetched.
        when(todoRepository.findOne(2L))
                .thenReturn(todo2);

        when(todoRepository.findOne(7L))
                .thenThrow(new TodoNotFoundException(TodoConstants.TODO_NOT_FOUND_EXCEPTION, 7L));

        // Return a list of todos when all fetched.
        when(todoRepository.findAll())
                .thenReturn(Arrays.asList(new Todo[]{todo1, todo2}));

        // Return a list of todos when all active fetched.
        when(todoRepository.findByActiveFlagTrue())
                .thenReturn(Arrays.asList(new Todo[]{todo1, todo2}));

        when(todoRepository.saveAndFlush(any(Todo.class)))
                .thenAnswer(invocation -> invocation.getArguments()[0]);

        // Return a new todo of ID 1 when fetched for assignee XBBLNNN.
        when(todoRepository.findByAssignee(eq("XBBLNNN")))
                .thenReturn(Arrays.asList(new Todo[]{todo1}));

        // Return a new todo of ID 2 when fetched for assignee XBBLYYY.
        when(todoRepository.findByAssignee(eq("XBBLYYY")))
                .thenReturn(Arrays.asList(new Todo[]{todo2}));

        // Throw an Exception when fetched for assignee XBBLXXX.
        when(todoRepository.findByAssignee(eq("XBBLXXX")))
                .thenThrow(new InvalidAssigneeException(TodoConstants.INVALID_NULL_ASSIGNEE_MESSAGE, "XBBLXXX"));

    }

    @Test
    /*
    The record to add is a JSON payload that looks like:

        {
            "name": "MyTodo 3",
            "assignee": "XBBLNNN",
            "due": "Today",
            "notes": "Some notes",
            "activeFlag": true
        }

    */
    public void addTodo() throws Exception {
        String todo3 = "{\"name\": \"MyTodo 3\",\"assignee\": \"XBBLNNN\",\"due\": \"Today\",\"notes\": \"Some notes\",\"activeFlag\": true}";

        given()
                .port(port)
                .when()
                    .body(todo3)
                    .contentType("application/json\r\n")
                    .post("/todos")
                .then()
                    .statusCode(201)
                    .body("todo.name", equalTo("MyTodo 3"),
                            "metadata.status.success", equalTo(Boolean.TRUE),
                            "metadata.status.statusCode", equalTo(HttpStatus.CREATED.getReasonPhrase()));

    }

    @Test
    /*
    An attempt to fetch the todoId of 1 should result in a HTTP 200 OK with response, similar to:

        {
            "metadata": {
                "serviceName": "Todo Service",
                "serviceVersion": "1.0",
                "status": {
                    "success": true,
                    "statusCode": "OK"
                },
                "requestId": "f24f2cf9-d044-4c0c-9f79-f40707c129ac",
                "requestTimestamp": "1499397004493",
                "responseId": "6a023dbd-8990-44fe-b2bd-93a49c3fceaf",
                "responseTimestamp": "1499397004493"
            },
            "todo": {
                "id": 1,
                "name": "MyTodo 1",
                "assignee": "XBBLNNN",
                "due": "Today",
                "notes": "Some notes",
                "activeFlag": true
            }
        }

    */
    public void getTodo() {
        given()
                .port(port)
                .when()
                    .get("/todos/{todoId}", 2)
                .then()
                    .statusCode(200)
                    .body("todo.id", equalTo(2),
                            "todo.name", equalTo("MyTodo 2"),
                            "metadata.status.success", equalTo(Boolean.TRUE),
                            "metadata.status.statusCode", equalTo(HttpStatus.OK.getReasonPhrase()));
    }

    @Test
    /*
        {
            "metadata": {
                "serviceName": "Todo Service",
                "serviceVersion": "1.0",
                "status": {
                    "success": false,
                    "statusCode": "Precondition Failed",
                    "statusDescription": "Invalid id input [null]"
                },
                "requestId": "0c270cf9-b17d-49bc-a5d5-398d54c55e28",
                "requestTimestamp": "1499397491467",
                "responseId": "bef6e2c5-bb00-479f-8a79-ef88916adb6d",
                "responseTimestamp": "1499397491467"
            },
            "issues": [
                {
                    "issueCode": "412",
                    "issueMessage": "Invalid id input [null]"
                }
            ]
        }

    */
    public void getNonExistingTodo() {
        String errorMessage = String.format(TodoConstants.INVALID_ID_MESSAGE, "x");
        given()
                .port(port)
                .when()
                    .get("/todos/{todoId}", "x")
                .then()
                    .statusCode(412)
                    .body("metadata.status.success", equalTo(Boolean.FALSE),
                            "metadata.status.statusCode", equalTo(HttpStatus.PRECONDITION_FAILED.getReasonPhrase()),
                            "metadata.status.statusDescription", equalTo(errorMessage),
                            "issues[0].issueCode", equalTo(HttpStatus.PRECONDITION_FAILED.toString()),
                            "issues[0].issueMessage", equalTo(errorMessage));
    }

    @Test
    public void getAllTodos() {
        given()
                .port(port)
                .when()
                    .get("/todos")
                .then()
                    .statusCode(200)
                    .body("metadata.status.success", equalTo(Boolean.TRUE),
                            "metadata.status.statusCode", equalTo(HttpStatus.OK.getReasonPhrase()),
                            "todos[0].id", equalTo(1),
                            "todos[1].id", equalTo(2));
    }

    @Test
    public void getAllActiveTodos() {
        given()
                .port(port)
                .when()
                    .param("includeInactive", Boolean.FALSE)
                    .get("/todos")
                .then()
                    .statusCode(200)
                    .body("metadata.status.success", equalTo(Boolean.TRUE),
                            "metadata.status.statusCode", equalTo(HttpStatus.OK.getReasonPhrase()),
                            "todos[0].name", equalTo("MyTodo 1"),
                            "todos[1].name", equalTo("MyTodo 2"));
    }

    @Test
    public void getTodosByAssignee() {

        given()
                .port(port)
                .when()
                    .get("/todos/assignees/{assignee}", "XBBLNNN")
                .then()
                    .statusCode(200)
                    .body("metadata.status.success", equalTo(Boolean.TRUE),
                            "metadata.status.statusCode", equalTo(HttpStatus.OK.getReasonPhrase()),
                            "todos[0].id", equalTo(1));
    }

    @Test
    public void getNonExistingAssignee() {

        String assignee = "XBBLXXX";

        String expectedMessage = String.format(TodoConstants.INVALID_NULL_ASSIGNEE_MESSAGE, assignee);

        given()
                .port(port)
                .when()
                    .get("/todos/assignees/{assignee}", assignee)
                .then()
                    .statusCode(412)
                    .body("metadata.status.success", equalTo(Boolean.FALSE),
                            "metadata.status.statusCode", equalTo(HttpStatus.PRECONDITION_FAILED.getReasonPhrase()),
                            "metadata.status.statusDescription", equalTo(expectedMessage));
    }

    @Test
    public void getSmallValueForAssignee() {
        String assignee = "ABC";

        String expectedMessage = String.format(TodoConstants.INVALID_ASSIGNEE_LENGTH_MESSAGE, assignee);

        given()
                .port(port)
                .when()
                    .get("/todos/assignees/{assignee}", assignee)
                .then()
                    .statusCode(412)
                    .body("metadata.status.success", equalTo(Boolean.FALSE),
                            "metadata.status.statusCode", equalTo(HttpStatus.PRECONDITION_FAILED.getReasonPhrase()),
                            "metadata.status.statusDescription", equalTo(expectedMessage));
    }

    @Test
    public void getLargeValueForAssignee() {
        String assignee = "ABCDEFGHIJKL";

        String expectedMessage = String.format(TodoConstants.INVALID_ASSIGNEE_LENGTH_MESSAGE, assignee);

        given()
                .port(port)
                .when()
                    .get("/todos/assignees/{assignee}", assignee)
                .then()
                    .statusCode(412)
                    .body("metadata.status.success", equalTo(Boolean.FALSE),
                            "metadata.status.statusCode", equalTo(HttpStatus.PRECONDITION_FAILED.getReasonPhrase()),
                            "metadata.status.statusDescription", equalTo(expectedMessage));
    }

    @Test
    public void updateTodo() {
        String todo1Update = "{\"id\": 1,\"name\": \"Updated MyTodo 1\",\"assignee\": \"XBBLNNN\",\"due\": \"Today\",\"notes\": \"Some " +
                "notes\",\"activeFlag\": true}";
        given()
                .port(port)
                .when()
                    .body(todo1Update)
                    .contentType("application/json\r\n")
                    .put("/todos/{todoId}", "1")
                .then()
                    .statusCode(200)
                    .body("metadata.status.success", equalTo(Boolean.TRUE),
                            "metadata.status.statusCode", equalTo(HttpStatus.OK.getReasonPhrase()),
                            "todo.name", equalTo("Updated MyTodo 1"));
    }

    @Test
    public void updateNonExistentTodo() {

        String todo7Update = "{\"id\": 7,\"name\": \"Updated MyTodo 7\",\"assignee\": \"XBBLNNN\",\"due\": \"Today\",\"notes\": \"Some " +
                "notes\",\"activeFlag\": true}";

        String errorMessage = String.format(TodoConstants.TODO_NOT_FOUND_EXCEPTION, "7");

        given()
                .port(port)
                .when()
                    .body(todo7Update)
                    .contentType("application/json\r\n")
                    .put("/todos/{todoId}", "7")
                .then()
                    .statusCode(404)
                    .body("metadata.status.success", equalTo(Boolean.FALSE),
                            "metadata.status.statusCode", equalTo(HttpStatus.NOT_FOUND.getReasonPhrase()),
                            "metadata.status.statusDescription", equalTo(errorMessage),
                            "issues[0].issueCode", equalTo(HttpStatus.NOT_FOUND.toString()),
                            "issues[0].issueMessage", equalTo(errorMessage));
    }

    @Test
    public void deleteTodo() {

        given()
                .port(port)
                .when()
                    .contentType("application/json\r\n")
                    .delete("/todos/{todoId}", "1")
                .then()
                    .statusCode(200)
                    .body("metadata.status.success", equalTo(Boolean.TRUE),
                            "metadata.status.statusCode", equalTo(HttpStatus.OK.getReasonPhrase()),
                            "todo.activeFlag", equalTo(Boolean.FALSE));
    }

    @Test
    public void deleteNonExistentTodo() {

        String errorMessage = String.format(TodoConstants.TODO_NOT_FOUND_EXCEPTION, "7");

        given()
                .port(port)
                .when()
                    .contentType("application/json\r\n")
                    .delete("/todos/{todoId}", "7")
                .then()
                    .statusCode(404)
                    .body("metadata.status.success", equalTo(Boolean.FALSE),
                            "metadata.status.statusCode", equalTo(HttpStatus.NOT_FOUND.getReasonPhrase()),
                            "metadata.status.statusDescription", equalTo(errorMessage),
                            "issues[0].issueCode", equalTo(HttpStatus.NOT_FOUND.toString()),
                            "issues[0].issueMessage", equalTo(errorMessage));
    }

}