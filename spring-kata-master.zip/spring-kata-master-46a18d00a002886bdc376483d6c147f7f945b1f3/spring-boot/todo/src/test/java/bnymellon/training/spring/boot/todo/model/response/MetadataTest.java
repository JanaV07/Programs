/*
 * Copyright 2017 BNY Mellon.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package bnymellon.training.spring.boot.todo.model.response;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class MetadataTest {

    private Metadata metadata1;
    private Metadata metadata2;
    private Metadata metadata3;
    private Metadata metadata4;

    @Before
    public void setUp() throws Exception {
        metadata1 = new Metadata();
        metadata1.setDescription("Description");
        metadata1.setRequestId("requestId");
        metadata1.setRequestTimestamp("requestTimestamp");
        metadata1.setResponseId("responseId");
        metadata1.setResponseTimestamp("responseTimestamp");
        metadata1.setServiceName("serviceName");
        metadata1.setServiceVersion("serviceVersion");
        metadata1.setStatus(null);


        metadata2 = new Metadata();
        metadata2.setDescription("Description");
        metadata2.setRequestId("requestId");
        metadata2.setRequestTimestamp("requestTimestamp");
        metadata2.setResponseId("responseId");
        metadata2.setResponseTimestamp("responseTimestamp");
        metadata2.setServiceName("serviceName");
        metadata2.setServiceVersion("serviceVersion");
        metadata2.setStatus(null);

        metadata3 = new Metadata();
        metadata3.setDescription("Description3");
        metadata3.setRequestId("requestId3");
        metadata3.setRequestTimestamp("requestTimestamp3");
        metadata3.setResponseId("responseId3");
        metadata3.setResponseTimestamp("responseTimestamp3");
        metadata3.setServiceName("serviceName3");
        metadata3.setServiceVersion("serviceVersion3");
        metadata3.setStatus(null);

        metadata4 = new Metadata();
        metadata4.setDescription("Description3");
        metadata4.setRequestId("requestId3");
        metadata4.setRequestTimestamp(null);
        metadata4.setResponseId("responseId3");
        metadata4.setResponseTimestamp(null);
        metadata4.setServiceName("serviceName3");
        metadata4.setServiceVersion("serviceVersion3");
        metadata4.setStatus(null);
    }

    @Test
    public void testEquals() throws Exception {
        assertEquals("Metadata1 and Metadata2 should be equal", metadata1, metadata2);
        assertNotEquals("Metadata1 and Metadata3 should not be equal", metadata1, metadata3);
        assertNotEquals("Metadata1 and Metadata3 should not be equal", metadata1, metadata4);
    }

    @Test
    public void testHashCode() throws Exception {
        assertEquals("Metadata1 and Metadata2 should have the same hashCode", metadata1.hashCode(), metadata2.hashCode());
        assertNotEquals("Metadata1 and Metadata3 should not have the same hashCode", metadata1.hashCode(), metadata3.hashCode());
        assertNotEquals("Metadata1 and Metadata3 should not have the same hashCode", metadata1.hashCode(), metadata4.hashCode());
    }

    @Test
    public void testToString() throws Exception {
        assertEquals("Metadata1 and Metadata2 should have the same toString", metadata1.toString(), metadata2.toString());
        assertNotEquals("Metadata1 and Metadata3 should not have the same toString", metadata1.toString(), metadata3.toString());
        assertNotEquals("Metadata1 and Metadata3 should not have the same toString", metadata1.toString(), metadata4.toString());
    }

}