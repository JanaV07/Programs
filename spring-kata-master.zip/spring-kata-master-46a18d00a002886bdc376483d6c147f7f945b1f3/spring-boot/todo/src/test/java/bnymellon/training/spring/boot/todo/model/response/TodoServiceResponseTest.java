/*
 * Copyright 2017 BNY Mellon.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package bnymellon.training.spring.boot.todo.model.response;

import java.util.Collections;

import org.junit.Before;
import org.junit.Test;

import bnymellon.training.spring.boot.todo.model.Todo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class TodoServiceResponseTest {
    private TodoServiceResponse todoServiceResponse1;
    private TodoServiceResponse todoServiceResponse2;
    private TodoServiceResponse todoServiceResponse3;
    private TodoServiceResponse todoServiceResponse4;

    @Before
    public void setUp() throws Exception {
        Todo todo1 = new Todo();
        todo1.setId(3L);
        todo1.setName("MyTodo 8");
        todo1.setActiveFlag(true);
        todo1.setAssignee("XBBLNNN");
        todo1.setDue("Today");
        todo1.setNotes("Some notes");

        Issue issue1 = new Issue();
        issue1.setIssueCode("IssueCode");
        issue1.setIssueMessage("IssueMessage");

        Metadata metadata1 = new Metadata();
        metadata1.setDescription("Description");
        metadata1.setRequestId("requestId");
        metadata1.setRequestTimestamp("requestTimestamp");
        metadata1.setResponseId("responseId");
        metadata1.setResponseTimestamp("responseTimestamp");
        metadata1.setServiceName("serviceName");
        metadata1.setServiceVersion("serviceVersion");
        metadata1.setStatus(null);

        todoServiceResponse1 = new TodoServiceResponse();
        todoServiceResponse1.setTodo(todo1);

        todoServiceResponse2 = new TodoServiceResponse();
        todoServiceResponse2.setTodo(todo1);

        todoServiceResponse3 = new TodoServiceResponse();
        todoServiceResponse3.setMetadata(metadata1);

        todoServiceResponse4 = new TodoServiceResponse();
    }

    @Test
    public void testEquals() throws Exception {
        assertEquals("TodoServiceResponse1 and TodoServiceResponse2 should be equal", todoServiceResponse1, todoServiceResponse2);
        assertNotEquals("TodoServiceResponse1 and TodoServiceResponse3 should not be equal", todoServiceResponse1, todoServiceResponse3);
        assertNotEquals("TodoServiceResponse1 and TodoServiceResponse3 should not be equal", todoServiceResponse1, todoServiceResponse4);
    }

    @Test
    public void testHashCode() throws Exception {
        assertEquals("TodoServiceResponse1 and TodoServiceResponse2 should have the same hashCode", todoServiceResponse1.hashCode(), todoServiceResponse2.hashCode());
        assertNotEquals("TodoServiceResponse1 and TodoServiceResponse3 should not have the same hashCode", todoServiceResponse1.hashCode(), todoServiceResponse3.hashCode());
        assertNotEquals("TodoServiceResponse1 and TodoServiceResponse3 should not have the same hashCode", todoServiceResponse1.hashCode(), todoServiceResponse4.hashCode());
    }

    @Test
    public void testToString() throws Exception {
        assertEquals("TodoServiceResponse1 and TodoServiceResponse2 should have the same toString", todoServiceResponse1.toString(), todoServiceResponse2.toString());
        assertNotEquals("TodoServiceResponse1 and TodoServiceResponse3 should not have the same toString", todoServiceResponse1.toString(), todoServiceResponse3.toString());
        assertNotEquals("TodoServiceResponse1 and TodoServiceResponse3 should not have the same toString", todoServiceResponse1.toString(), todoServiceResponse4.toString());
    }

}