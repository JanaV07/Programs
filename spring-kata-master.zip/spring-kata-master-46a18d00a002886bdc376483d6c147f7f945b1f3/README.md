# **What is the spring-course?**

The Spring course consists of two related tutorials that teach developers about Spring Framework and then Spring Boot. The courses lay out examples that are discussed via presentations, located under the `presentations` directory.

The best way to take this course is to checkout the entire project locally, then launch the `presentations\spring-framework.html` for the Spring Framework tutorial or the `presentations\spring-boot.html` for a Spring Boot tutorial.

The courses are fairly independent, someone who knows Spring framework well, need only visit the Spring Boot tutorial to get up to speed. However it is worth hitting a refresher and going through the Spring Framework content (even if solving the exercises is not attempted).

## Notes about the presentation:
 
1. Please use the space bar (guarantees order) or arrow keys (up, down, right left).
2. There is a tiny menu towards the bottom left. This allows you to navigate pages as well as alter to a Dark or a Light theme.
3. This is in no way a comprehensive list of all cool features of Spring and Spring Boot, and is meant as a beginner introduction.
